#pragma once
#include<iostream>
using namespace std;
void StartThePVPGame();//��ʼ��Ϸ