#pragma once
#include<iostream>
#include"publicFunction.h"
using namespace std;
void StartThePVEGame();//�˻�ģʽ
void AIPlaying(vector<string> &checkerboard,vector<bool> &isEnable,int turn,int AImod);//�����㷨